#!/bin/bash
#SBATCH 
#SBATCH --reservation=
#SBATCH  --mem=48G 
#SBATCH  -v
#SBATCH  -s 
#SBATCH  --output=/mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/chass_symmetric3//stats//individual_label_statistics//sbatch//slurm-%j.out 
#$ -l h_vmem=48G,vf=48G 
#$ -N N57580_calculate_individual_label_statistics 
#$ -M rja20@duke.edu 
#$ -m ea 
#$ -o /mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/chass_symmetric3//stats//individual_label_statistics//sbatch//slurm-$JOB_ID.out 
#$ -e /mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/chass_symmetric3//stats//individual_label_statistics//sbatch//slurm-$JOB_ID.out 
/mnt/clustertmp/common/rja20_dev//matlab_execs_for_SAMBA//write_individual_stats_executable/run_write_individual_stats_exec_v2.sh /mnt/clustertmp/common/rja20_dev//MATLAB2015b_runtime/v90 N57580 /mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/chass_symmetric3//N57580_chass_symmetric3_labels.nii.gz dwi /mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/images/ /mnt/BIAC/munin3.dhe.duke.edu/Badea/Lab/mouse/VBM_20APOE01_chass_symmetric3_allAPOE-work/dwi/SyN_0p5_3_0p5_dwi/dwiMDT_NoNameYet_n32_i5/stats_by_region/labels/pre_rigid_native_space/chass_symmetric3//stats//individual_label_statistics/ native chass_symmetric3  1 
